import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormControl, FormGroup,  Validators } from '@angular/forms';
import { stringify } from '@angular/core/src/util';

@Component({
  selector: 'app-comp2',
  templateUrl: './comp2.component.html',
  styleUrls: ['./comp2.component.css']
})
export class Comp2Component implements OnInit {
  Empformgroup:FormGroup;
  empno:number;
  empname:string;
  salary:number;
  fields:Array<string>=[];

  constructor(formBuilder:FormBuilder) {
    this.Empformgroup=formBuilder.group(
      {
        "enocontrol":new FormControl("",Validators.required),
        "enamecontrol":new FormControl("",[Validators.required,Validators.minLength(4),Validators.maxLength(10)]),
        "esalcontrol":new FormControl("",[Validators.required,Validators.min(100),Validators.max(1000)]),
        "emailcontrol":new FormControl("",[Validators.email])
      }
    );

  this.fields=Object.keys(this.Empformgroup.controls)
  console.log(this.fields);
   }

   display(){
    console.log(this.Empformgroup);
  }
  ngOnInit() {
  }

}
