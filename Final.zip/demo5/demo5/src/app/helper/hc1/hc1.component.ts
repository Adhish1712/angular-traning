import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hc1',
  templateUrl: './hc1.component.html',
  styleUrls: ['./hc1.component.css']
})
export class Hc1Component implements OnInit {
  title:string="Test";
  
  constructor() { }

  ngOnInit() {
  }

}
