import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommService {

  constructor(private http:HttpClient) { }

  public postDetails(obj:object):Observable<any>
  {
    return this.http.post("https://reqres.in/api/users",obj);
  }

  public sendGeneric(req:HttpRequest<any>):Observable<any>{
    return this.http.request(req)
  }
}
