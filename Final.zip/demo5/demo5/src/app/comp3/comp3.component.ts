import { Component, OnInit } from '@angular/core';
import { CommService } from '../comm.service';
import { HttpRequest } from '@angular/common/http';

@Component({
  selector: 'app-comp3',
  templateUrl: './comp3.component.html',
  styleUrls: ['./comp3.component.css']
})
export class Comp3Component implements OnInit {
 usr:object={};
 resp:object={};
 url: string="https://reqres.in/api/users?page=2"
 reqType:any ="GET";
  constructor(private cs:CommService ) { }

  ngOnInit() {
  }

  send(){
    this.cs.postDetails(this.usr).subscribe(
       (value)=>{console.log(value);this.resp=value;},
       (error)=>{console.log(error)}
    );
  }

  sendGeneric()
  {
    let req=new HttpRequest(this.reqType,this.url);
    this.cs.sendGeneric(req).subscribe(
      (value)=>{console.log(value);this.resp=value;},
      (error)=>{console.log(error)}
   );

  }

}
