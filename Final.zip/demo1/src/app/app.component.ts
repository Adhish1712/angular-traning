import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title: string = 'Mama Bawa' ;
  name: string = 'Shailu' ;
  image1: string='../assets/image.png';
  showimage:boolean=true;

  public toggleimage(): void {
    this.showimage=!this.showimage;
      if(this.showimage)
      {
        this.image1='../assets/images1.png';
      }
      else
      {
        this.image1='../assets/image.png';
      }

  };
}
