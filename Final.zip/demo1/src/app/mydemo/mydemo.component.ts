import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mydemo',
  templateUrl: './mydemo.component.html',
  styleUrls: ['./mydemo.component.css']
})
export class MydemoComponent {

  cout: number=0;

  public add():void{
    this.cout++;
    console.log("add invoked...");
  }

}
