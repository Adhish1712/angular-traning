import { Directive } from '@angular/core';

@Directive({
  selector: '[appShowdirective]'
})
export class ShowdirectiveDirective {

  constructor() { 
    console.log("in show directive")
  }

}
