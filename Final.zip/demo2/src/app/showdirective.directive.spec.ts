import { ShowdirectiveDirective } from './showdirective.directive';

describe('ShowdirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new ShowdirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
