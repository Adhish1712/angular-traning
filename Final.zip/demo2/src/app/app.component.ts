import { Component } from '@angular/core';
import { Emp } from './emp';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo2';
  emp: Emp = new Emp();
  emparr: Array<Emp>=new Array();

  constructor(){
  
      this.emparr.push( 
       {"empno": 1, "ename": "1", "salary": 1 }
      ,{ "empno": 2, "ename": "2", "salary": 2 }
      ,{ "empno": 3, "ename": "3", "salary": 3 }
      ,{ "empno": 4, "ename": "4", "salary": 4 }
      ,{ "empno": 5, "ename": "5", "salary": 5 }
      );
  }

  public add():void{
   console.log("added");
    this.emparr.push(this.emp);
    this.emp= new Emp();
  }

  public delete(row :number):void{
    console.log("delete");
     this.emparr.splice(row,1);
   }

   public edit(row :number):void{
    console.log("edit");
   //this.emparr.splice(row,1);
   }
}
