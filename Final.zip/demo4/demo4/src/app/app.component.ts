import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name:string="demo4";
  marks:number=1;

  handleinvalid(str :string)
  {
   console.log("Custom Handler");
   console.log(str);
   this.marks=0;
  }

}
