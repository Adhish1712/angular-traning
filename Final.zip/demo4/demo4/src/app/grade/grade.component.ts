import { Component, OnInit, OnChanges,SimpleChanges, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-grade',
  templateUrl: './grade.component.html',
  styleUrls: ['./grade.component.css']
})
export class GradeComponent implements OnInit,OnChanges {
  ngOnChanges(changes:SimpleChanges): void {
    this.calGrade();
    //console.log(changes);
  }
 grade:String="notdetected";
 @Input()mrks:number=0;
 @Output()Invalid:EventEmitter<string>= new EventEmitter();

  constructor() { 
    //this.calGrade();
  }

  ngOnInit() {
    this.calGrade();
  }

  calGrade(){
    if(this.mrks>35)
    {
     this.grade='Pass';
    }else
    {
      this.grade='FAil';
    }
    if(this.mrks>100)
    {
      this.Invalid.emit("Invalid mrks"+this.mrks);
    }
  }
}
