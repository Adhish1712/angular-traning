import { Component, OnInit } from '@angular/core';
import {CounterService} from'../counter.service';

@Component({
  selector: 'app-copm1',
  templateUrl: './copm1.component.html',
  styleUrls: ['./copm1.component.css']
})
export class Copm1Component implements OnInit {

  constructor(private myservice:CounterService) { }

  ngOnInit() {
  }
   
  currentcnt:number;

  public invoke() : void{
    console.log("invoke");
    this.myservice.incr();
    this.currentcnt=this.myservice.getcount();
  }

}
