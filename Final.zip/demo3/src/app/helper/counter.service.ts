import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CounterService {
count:number =0;
  constructor() { 
    console.log("Counter service");
  }

  incr(){
    this.count++;
  }
  getcount():number{
    return this.count;
  }
}
