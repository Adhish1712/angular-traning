import { Component, OnInit } from '@angular/core';
import {CounterService} from'../counter.service';

@Component({
  selector: 'app-copm2',
  templateUrl: './copm2.component.html',
  styleUrls: ['./copm2.component.css']
})
export class Copm2Component implements OnInit {

  constructor(private myservice:CounterService) { }
   
  currentcnt:number;
  ngOnInit() {
  }

  public invoke() : void{
    console.log("invoke");
    this.myservice.incr();
    this.currentcnt=this.myservice.getcount();
  }

}
