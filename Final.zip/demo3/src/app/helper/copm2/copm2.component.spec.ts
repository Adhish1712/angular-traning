import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Copm2Component } from './copm2.component';

describe('Copm2Component', () => {
  let component: Copm2Component;
  let fixture: ComponentFixture<Copm2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Copm2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Copm2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
