import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Copm3Component } from './copm3.component';

describe('Copm3Component', () => {
  let component: Copm3Component;
  let fixture: ComponentFixture<Copm3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Copm3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Copm3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
