import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Copm1Component } from './copm1/copm1.component';
import { Copm2Component } from './copm2/copm2.component';
import { Copm3Component } from './copm3/copm3.component';
import { CounterService } from './counter.service';

@NgModule({
  declarations: [Copm1Component, Copm2Component, Copm3Component],
  imports: [
    CommonModule
  ],
  exports:[Copm1Component,Copm2Component,Copm3Component],
  providers:[CounterService]
})
export class HelperModule { }
